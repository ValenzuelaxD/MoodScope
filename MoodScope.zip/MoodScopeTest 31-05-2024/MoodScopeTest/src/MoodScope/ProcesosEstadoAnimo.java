/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package MoodScope;

import java.util.ArrayList;



/**
 *
 * @author wzyx_
 */
public interface ProcesosEstadoAnimo {
    
    Double obtenerElementoEnPosicion();
    
    double calcularPromedio(ArrayList<Double> lista);
}
